1) داخل config.xml مقدار id="com.iran.antiguardian.game" رو بذار همون نام پکیجی که توی مایکت ثبت کردی.
2) این پوشه رو توی یک مخزن گیت‌هاب بریز (Private باشه). 
3) تب Actions -> Build APK -> بعد از تموم شدن، پایین صفحه فایل game-apk رو دانلود کن.

ONLINE OFFERS CONFIGURATION
The game fetches online offers from this public GitHub repository:
https://github.com/sashawybrayt339-eng/Ghksmp
Raw offers file (must be committed at the repository root on branch main):
https://raw.githubusercontent.com/sashawybrayt339-eng/Ghksmp/main/offers.json
To publish new offers without a Myket app update, edit offers.json in that repository and commit the change. The already-installed game must contain this online-fetch code.
